import sqlite3
import csv2sqlite


def main():

    f = open('insegnamenti.csv', 'r')  # open the csv data file
    next(f, None)  # skip the header row
    reader = csv2sqlite.reader(f)

    sql = sqlite3.connect('site.db')
    cur = sql.cursor()

    cur.execute('''CREATE TABLE IF NOT EXISTS insegnamenti
                (class_id, class_name, credits real)''')  # create the table if it doesn't already exist

    for row in reader:
        cur.execute("INSERT INTO insegnamenti VALUES (?, ?, ?)", row)

    f.close()
    sql.commit()
    sql.close()

if __name__ == '_main_':
    main()