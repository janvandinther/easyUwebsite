from application import db, login_manager
from datetime import datetime
from flask_login import UserMixin

@login_manager.user_loader
def load_user(user_username):
    return User.query.get(user_username)




class User(db.Model, UserMixin):
    username = db.Column(db.String(20), primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)
    posts = db.relationship('Post', backref='author', lazy=True)

    def __repr__(self):
        return "User('{self.username}, '{self.email}'}''"

    def get_id(self):
        return self.username

class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), unique=True, nullable=False)
    date_posted = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    content = db.Column(db.Text, nullable=False)

    user_id = db.Column(db.String, db.ForeignKey('user.username'), nullable=False)

    def __repr__(self):
        return "User('{self.title}, '{self.date_posted}''"


class StudyRoom(db.Model):
    room_id = db.Column(db.Integer, primary_key=True)
    room_name = db.Column(db.String, nullable=False)
    available_spots = db.Column(db.Integer, nullable=False)
    address = db.Column(db.String, nullable=False)

    def __repr__(self):
        return "Study Room('{self.study_room}, '{self.opening_hours}', '{self.available_spots', '{self.address}' ' "


class Course(db.Model):
    course_id = db.Column(db.Integer, primary_key=True)
    course_name = db.Column(db.String, nullable=False)
    area = db.Column(db.String, nullable=False)
    level = db.Column(db.Integer, nullable=False)
    def __repr__(self):
        return "Course('{self.course_id}, '{self.course_name}', '{self.area', '{self.level}' ' "

class Class(db.Model):
    class_id = db.Column(db.Integer, primary_key=True)
    class_name = db.Column(db.String, nullable=False)
    credits = db.Column(db.String, nullable=False)



    def __repr__(self):
        return "Course('{self.course_id}, '{self.course_name}', '{self.area', '{self.level}' ' "




'''list = [['Aula1', 'Mon-Fry: 8.30-19.30', 100, 'Sede Centrale'],
        ['Aula2', 'Mon-Fry: 8.30-19.30', 100, 'Sede Centrale'],
        ['Aula3', 'Mon-Wed: 9.00-20.00', 50, 'Cittadella Politecnica']]
for s in range(list.__len__()):
    st = StudyRoom(study_room=list[s][0], opening_hours=list[s][1],
                   available_spots=list[s][2], address=list[s][3])
    db.session.add(st)
    db.session.commit()

courses = [[1, 'INGEGNERIA GESTIONALE-CLASSE L8', 'INGEGNERIA', 1],
           [2, 'INGEGNERIA GESTIONALE-CLASSE L9', 'INGEGNERIA', 1],
           [3, 'ENGINEERING AND MANAGEMENT', 'INGEGNERIA', 2],
           [4, 'INGEGNERIA GESTIONALE', 'INGEGNERIA', 2]]

for c in range(courses.__len__()):
     cr = Course(course_id=courses[c][0], course_name=courses[c][1],
                 area =courses[c][2], level=courses[c][3])
     db.session.add(cr)
     db.session.commit()'''